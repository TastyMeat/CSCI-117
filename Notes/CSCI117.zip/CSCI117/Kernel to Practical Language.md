Kernel is too minimal and we have to add syntactic sugar & linguistic abstractions to it:
-   It defines a set of syntactic conveniences that give a more concise and read- able full syntax.
    
-   It defines an important linguistic abstraction(functions) that is useful for concise and readable programming.
    
-   It explains the interactive interface of the Mozart system and shows how it relates to the declarative model. This brings in the declare statement, which is a variant of the local statement designed for interactive use.