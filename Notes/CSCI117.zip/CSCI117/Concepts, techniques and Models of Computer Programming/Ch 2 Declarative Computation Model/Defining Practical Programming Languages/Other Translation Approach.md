Not used in CTM
##### Foundational Approach
for mathematicians, have minimum elements
1) lambda calculus: functional programming
2) first-order logic: logic programming
3) pi calculus: model concurrency
##### Machine Approach
intended for the implementor, programs translated into idealized machine(abstract/ virtual machine)