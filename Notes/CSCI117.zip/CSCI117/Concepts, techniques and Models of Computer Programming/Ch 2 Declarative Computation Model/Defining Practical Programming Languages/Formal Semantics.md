1) Operational
	- how a statement executes on an abstract machine
	- works well everywhere
1) Axiomatic
	- defines a statement’s semantics as the relation between the input state (the situation before executing the statement) and the output state (the situation after executing the statement)
	- works well with stateful models
1) Denotational
	- defines a statement as a function over abstract domain
	- gets complicated with concurrent models
1) Logical
	- defines a statement as a logical theory
	- works well with declerative & relational computation models only
	