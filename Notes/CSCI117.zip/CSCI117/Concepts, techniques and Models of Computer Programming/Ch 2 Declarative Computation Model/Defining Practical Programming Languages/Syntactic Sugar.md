Basically a short-cut notation for expressions that repeats in the program

Example:
![[full notation vs syntactic sugar.png]]

##### 4 types of sugar?