Basically extending the language and extending its linguistic construct.
- An abstraction
- An addition to the language syntax
- increases expressiveness of the language

Phases of defining a linguistic abstraction
1) Define a new grammatical construct
2) Define a translation into kernel language

