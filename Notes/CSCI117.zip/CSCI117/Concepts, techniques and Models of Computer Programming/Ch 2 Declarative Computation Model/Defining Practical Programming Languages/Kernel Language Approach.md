All program translates into a core language(kernel language)
There are 2 main parts:
1) define a simple language, easy to reason, faithful to space and time efficiency
	- kernel language + data structures -> kernel computational model
2) define a translation scheme, gramatical construct are translated into kernel and there are 2 types of translation:
	1) [[Syntactic Sugar]]
	2) [[Linguistic Abstraction]]
3) 