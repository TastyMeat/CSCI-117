`(proc{$⟨y⟩1 ... ⟨y⟩n}⟨s⟩end, CE )`
- contains an environment and a procedure definition
- when procedure is called, the contextual environment is used to construct the environment executing the procedure body
	- able to reference the store and identifiers outside its procedure scope