1. Initial execution state
	- `( [(⟨s⟩, φ)], φ )`
	- store (ST) and environment (E) empty
2. executing outer local and X=1 stateement
	- `( [(⟨s⟩1⟨s⟩2, {X → x})], {x = 1} )`
	- identifier X -> x and bound to 1, next execution is sequential composition (`⟨s⟩1⟨s⟩2`)
3. executing sequential composition
	- `( [(⟨s⟩1, {X → x}), (⟨s⟩2, {X → x})], {x = 1} )`
	- `⟨s⟩1` and `⟨s⟩2` have their own environment, but now same value
4. start `⟨s⟩1` execution
	- `( [(X=2 {Browse X}, {X → x′}), (⟨s⟩2, {X → x})], {x′,x = 1} )`
	- creates new variable `x′` 
	- calculates new environement `{X → x} + {X → x′}`, which is `{X → x′}`
	- second mapping of X overrides the first
5. after binding X=2
	- `( [({Browse X}, {X → x′}), ({Browse X}, {X → x})], {x′= 2,x = 1} )`
	- inner local statement given its own environment, does not affect outer local statement