##### Procedural Abstraction
any statement can be turned into a procedure by placing it inside a procedure decleration
##### Free Identifiers
not defined when the procedure is defined, but defined in an enclosing statement 
##### Static Scoping/ [[Lexical Scoping]]
The value of an external reference is its value when the procedure is defined