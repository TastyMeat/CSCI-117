##### Hoz Syntax:
	{ByNeed X Y}
##### Explanation:
- X = procedure 1 arg
- Y = trigger
- when Y is needed X will compute the value,
   when Y is not needed X is never run. 
   