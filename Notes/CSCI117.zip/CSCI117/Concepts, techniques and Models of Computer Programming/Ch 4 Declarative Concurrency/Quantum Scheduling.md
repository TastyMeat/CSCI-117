##### Hoz Syntax: 
	runFullT (Fin n) 
	runFullT (Infinity)

##### Characteristics:
1) Choose a Quantum(a finite value) threads will run the amount of statements specified by the quantum`
