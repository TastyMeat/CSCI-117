Data Dependent and Data Driven Idea
The computation are dependent of other data
##### Idea:
[[Data Driven Concurrency]]
##### Structure:
1) [[Threads]]
2) [[Class Notes - Lazy Execution]]
