1) Is interleaving the same as parallelism
2) Which takes priority, precedence or associativity
3) if there are no binding in procedure decleration what will happen [[Kernel Language Semantics]]
4) bound variables vs bound identifiers [[Lexical Scoping]]
5) procedural application [[Types of Suspendable Statements]]
